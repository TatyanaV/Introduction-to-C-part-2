/***************************************************
Tatyana Vlaskin
Lab#1
Problem 1
06.29.2014
name: f.h
This program demonstrate 2 functions that are declared
in separate header files in namespace A. Those 2 functions
are defined in 2 separate implementation files in namespace A.
Those 2 functions are called in main.cpp
program using local using declarations.
**************************************************************/


//header files
#include<iostream>

//namespace A is created
//declaration of the f() function
namespace A {
  void f();
}
